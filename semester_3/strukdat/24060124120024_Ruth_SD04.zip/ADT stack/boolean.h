#ifndef boolean_H
#define boolean_H
typedef enum {false, true} boolean;
#endif