// ======================================================
// Nama Program: tqueue2.h
// Deskripsi   : header ADT Tqueue2
// NIM/Nama    : 24060124120024/Ruth Septriana Sipangkar
// Tanggal     : 02/10/2025
// ======================================================
#include <stdio.h>
#include "tqueue2.h"


void createQueue2(tqueue2 *Q){
    for(int i=1; i<6; i++){
        Q->wadah[i] = '-';
    }
    Q->head = 0;
    Q->tail = 0;
}

int head2(tqueue2 Q){
    return Q.head;
}

int tail2(tqueue2 Q){
    return Q.tail;
}

char infoHead2(tqueue2 Q){
    return Q.wadah[Q.head];
}

char infoTail2(tqueue2 Q){
    return Q.wadah[Q.tail];
}

int sizeQueue2(tqueue2 Q){
    return Q.tail - Q.head;
}

boolean isEmptyQueue2(tqueue2 Q){
    return Q.head == 0 && Q.tail == 0;
}
 
boolean isFullQueue2(tqueue2 Q){
    return Q.head == 1 && Q.tail == 6;
}

boolean isOneElement2(tqueue2 Q){
    return Q.head == Q.tail && Q.tail == 1;
}

boolean isTailStop(tqueue2 Q){
    return Q.tail == 6;
}

void printQueue2(tqueue2 Q){
    printf("Print queue : |");
    for(int i=1; i<6; i++){
        printf(" %c", Q.wadah[i]);
    }
    printf(" |\n");
}

void viewQueue2(tqueue2 Q){
    printf("View queue  : |");
    for(int i=head2(Q); i<=tail2(Q); i++){
        printf(" %c", Q.wadah[i]);
    }
    printf(" |\n");
}

void resetHead(tqueue2 *Q){
    if(isTailStop(*Q) && !isFullQueue2(*Q)){
        for(int i=1; i<=6; i++){
            Q->wadah[i] = Q->wadah[i+1];
        }
        Q->wadah[Q->tail] = '-';
        Q->tail = sizeQueue2(*Q);
    }
}

void enqueue2(tqueue2 *Q, char E){
    if(!isTailStop(*Q) && !isFullQueue2(*Q)){
        Q->tail ++;
        Q->wadah[Q->tail] = E;
    } else if(isTailStop(*Q) && !isFullQueue2(*Q)){
        resetHead(Q);
        Q->tail ++;
        Q->wadah[Q->tail] = E;
    }
}

void dequeue2(tqueue2 *Q, char *E){
    if(!isOneElement2(*Q)){
        *E = infoHead2(*Q);
        Q->wadah[Q->tail] = '-';
        Q->tail = 0;
        Q->head = 0;
    } else if (!isEmptyQueue2(*Q)){
        *E = infoHead2(*Q);
        Q->wadah[Q->tail] = '-';
        Q->tail --;
    }
}

void enqueue2N(tqueue2 *Q, int N);

boolean isEqualQueue2(tqueue2 Q1,tqueue2 Q2);