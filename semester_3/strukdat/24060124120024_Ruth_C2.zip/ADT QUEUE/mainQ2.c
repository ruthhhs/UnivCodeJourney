// ======================================================
// Nama Program: mainQ2.h
// Deskripsi   : driver ADT Tqueue2
// NIM/Nama    : 24060124120024/Ruth Septriana Sipangkar
// Tanggal     : 02/10/2025
// ======================================================
#include <stdio.h>
#include "tqueue2.h"

int main(){
    // Kamus
    tqueue2 A, B;
    char x;

    // Algoritma
    printf("========== ADT QUEUE TYPE 2 =========\n");
    createQueue2(&A);
    printQueue2(A);
    viewQueue2(A);

    printf("Enqueue\n");
    enqueue2(&A, 'a');
    enqueue2(&A, 'y');
    enqueue2(&A, 'a');
    enqueue2(&A, 'm');
    printQueue2(A);
    viewQueue2(A);

    dequeue2(&A, &x);
    printf("Dequeue : %c\n", x);
    printQueue2(A);
    viewQueue2(A);

    dequeue2(&A, &x);
    printf("Dequeue : %c\n", x);
    printQueue2(A);
    viewQueue2(A);

    printf("Enqueue\n");
    enqueue2(&A, 'y');
    printQueue2(A);
    viewQueue2(A);

    printf("Enqueue\n");
    enqueue2(&A, 'a');
    printQueue2(A);
    viewQueue2(A);

    printf("Enqueue\n");
    enqueue2(&A, 'm');
    printQueue2(A);
    viewQueue2(A);

}