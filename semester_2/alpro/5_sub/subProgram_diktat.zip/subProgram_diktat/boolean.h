#ifndef BOOLEAN_H
#define BOOLEAN_H

#define true 1
#define false 0
typedef int boolean;  /* Boolean direpresentasikan sebagai int */

#endif